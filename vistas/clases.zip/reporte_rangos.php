<?php
//Activamos el almacenamiento en el buffer
ob_start();
session_start();
date_default_timezone_set("America/Mazatlan");



if (!isset($_SESSION["nombre"]))
{
  header("Location: login.html");
}
else
{
require 'header.php';

if ($_SESSION['Escritorio']==1)
{
require_once "../config/Conexion.php";
?>


  <head>
      
      
      
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['', ''],
<?php
$sql_fetch_todos = "select * from registros_material_c GROUP BY nombre HAVING COUNT(*) < 50;";
$query = mysqli_query($conexion, $sql_fetch_todos);

             
                while ($row = mysqli_fetch_assoc($query)) { 
                 echo "['" .$row['nombre']. "'," .$row['id']. "],";
                }
?>
        ]);

        var options = {
          title: 'LIDERES CON MENOS DE 50 EVIDENCIAS'
        };

        var chart = new google.visualization.PieChart(document.getElementById('menosde50'));

        chart.draw(data, options);
      }
    </script>
    
    
     <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['', ''],
<?php
$sql_fetch_todos = "select * from registros_material_c GROUP BY nombre HAVING COUNT(*) > 50 && COUNT(*) < 100;";
$query = mysqli_query($conexion, $sql_fetch_todos);

             
                while ($row = mysqli_fetch_assoc($query)) { 
                 echo "['" .$row['nombre']. "'," .$row['id']. "],";
                }
?>
        ]);

        var options = {
          title: 'LIDERES CON MAS DE 50 y MENOS DE 100 EVIDENCIAS'
        };

        var chart = new google.visualization.PieChart(document.getElementById('masde50menosde100'));

        chart.draw(data, options);
      }
    </script>
  
  
  
         <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['', ''],
<?php
$sql_fetch_todos = "select * from registros_material_c GROUP BY nombre HAVING COUNT(*) > 100 && COUNT(*) < 200;";
$query = mysqli_query($conexion, $sql_fetch_todos);

             
                while ($row = mysqli_fetch_assoc($query)) { 
                 echo "['" .$row['nombre']. "'," .$row['id']. "],";
                }
?>
        ]);

        var options = {
          title: 'LIDERES CON ENTRE 100 Y 200 REGISTROS DE EVIDENCIAS'
        };

        var chart = new google.visualization.PieChart(document.getElementById('masde100'));

        chart.draw(data, options);
      }
    </script>
    
    
         <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['', ''],
<?php
$sql_fetch_todos = "select * from registros_material_c GROUP BY nombre HAVING COUNT(*) > 200 && COUNT(*) < 300;";
$query = mysqli_query($conexion, $sql_fetch_todos);

             
                while ($row = mysqli_fetch_assoc($query)) { 
                 echo "['" .$row['nombre']. "'," .$row['id']. "],";
                }
?>
        ]);

        var options = {
          title: 'LIDERES CON ENTRE 200 y 300 REGISTROS DE EVIDENCIAS'
        };

        var chart = new google.visualization.PieChart(document.getElementById('entre200y300'));

        chart.draw(data, options);
      }
    </script>    
    
    
         <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['', ''],
<?php
$sql_fetch_todos = "select * from registros_material_c GROUP BY nombre HAVING COUNT(*) > 300 && COUNT(*) < 400;";
$query = mysqli_query($conexion, $sql_fetch_todos);

             
                while ($row = mysqli_fetch_assoc($query)) { 
                 echo "['" .$row['nombre']. "'," .$row['id']. "],";
                }
?>
        ]);

        var options = {
          title: 'LIDERES CON ENTRE 300 Y 400 REGISTROS DE EVIDENCIAS'
        };

        var chart = new google.visualization.PieChart(document.getElementById('entre300y400'));

        chart.draw(data, options);
      }
    </script>  
    
         <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['', ''],
<?php
$sql_fetch_todos = "select * from registros_material_c GROUP BY nombre HAVING COUNT(*) > 400;";
$query = mysqli_query($conexion, $sql_fetch_todos);

             
                while ($row = mysqli_fetch_assoc($query)) { 
                 echo "['" .$row['nombre']. "'," .$row['id']. "],";
                }
?>
        ]);

        var options = {
          title: 'LIDERES CON MÁS DE 400 REGISTROS DE EVIDENCIAS'
        };

        var chart = new google.visualization.PieChart(document.getElementById('entre400y500'));

        chart.draw(data, options);
      }
    </script>      
  </head>
  <body>
      
     <div class="nav">
         <div class="row">
            <div class="col-md-4" >
                  <button class="btn" style="width:100%;height:50px;"><a href="reportes.php" style="color:black;"><li class="fa fa-list">  REPORTE GENERAL</li></a></button>

            </div>
            <div class="col-md-4">
                  <button style="width:100%;height:50px;" class="btn"><a href="reporte_lista.php" style="color:black;"><li class="fa fa-list">  REPORTE POR LIDER</li></a></button>

            </div>   
            <div class="col-md-4">
                  <button style="width:100%;height:50px;background-image: linear-gradient(#98989A, #9F2241);" class="btn"><a href="reporte_rangos.php" style="color:white;"><li class="fa fa-list">  REPORTE POR RANGOS</li></a></button>

            </div>            
         </div>
     </div>
     

    <div id="menosde50" style="width: 100%; height: 1200px;"></div>  
    <div id="masde50menosde100" style="width: 100%; height: 1200px;"></div>  
    <div id="masde100" style="width: 100%; height: 1200px;"></div>  
    <div id="entre200y300" style="width: 100%; height: 1200px;"></div>  
    <div id="entre300y400" style="width: 100%; height: 1200px;"></div>  
    <div id="entre400y500" style="width: 100%; height: 1200px;"></div>  

             


  </body>
    <!-- Fin Contenido PHP-->
    <?php
}
else
{
 require 'noacceso.php';
}
require 'footer.php';
}
ob_end_flush();
?>