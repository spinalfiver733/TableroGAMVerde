<?php
//Activamos el almacenamiento en el buffer
ob_start();
session_start();

if (!isset($_SESSION["nombre"]))
{
  header("Location: login.html");
}
else
{
require 'header.php';
require 'scripts/scriptE.js';

if ($_SESSION['Escritorio']==1)
{

?>
<!--Contenido-->




<header>
    <style>
        #mapCanvas {
    width: 100%;
    height: 650px;
}
     </style>   
</header>


<body>
   
   
   
<iframe
width="100%"
height="600px"
  src="https://www.google.com/maps/d/edit?mid=1q56ar8U0PJgPoKZ8W3SGXZoQxFC_MI4&ll=19.519271396536183%2C-99.11357589999999&z=12">
</iframe>

<br><br>

<script type=text/javascript>

document.oncontextmenu = function(){return false;}

</script>

  <!--Fin-Contenido-->
<?php
}

require 'footer.php';
?>
<script src="../public/js/chart.min.js"></script>
<script src="../public/js/Chart.bundle.min.js"></script> 

<?php 
}
ob_end_flush();
?>
