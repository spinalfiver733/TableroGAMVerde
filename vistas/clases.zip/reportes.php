<?php
//Activamos el almacenamiento en el buffer
ob_start();
session_start();
date_default_timezone_set("America/Mazatlan");



if (!isset($_SESSION["nombre"]))
{
  header("Location: login.html");
}
else
{
require 'header.php';

if ($_SESSION['Escritorio']==1)
{
require_once "../config/Conexion.php";
?>


  <head>
      
      
      
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['', ''],
<?php
$sql_fetch_todos = "select *  from registros_material_c  group by nombre;";
$query = mysqli_query($conexion, $sql_fetch_todos);

                while ($row = mysqli_fetch_assoc($query)) { 
                 echo "['" .$row['nombre']. "'," .$row['id']. "],";
                }
?>
        ]);

        var options = {
          title: 'LIDERES CON MENOS DE 50 EVIDENCIAS'
        };

        var chart = new google.visualization.PieChart(document.getElementById('menosde50'));

        chart.draw(data, options);
      }
    </script>
    
    
    
    
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['', ''],
<?php
$sql_fetch_todos = "select *  from registros_material_c where servicio = 'sheimbaun'  group by nombre ;";
$query = mysqli_query($conexion, $sql_fetch_todos);

                while ($row = mysqli_fetch_assoc($query)) { 
                 echo "['" .$row['nombre']. "'," .$row['id']. "],";
                }
?>
        ]);

        var options = {
          title: 'GRÁFICA GENERAL DE AMBAS CANDIDATAS'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart'));

        chart.draw(data, options);
      }
    </script>
    
    
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
<?php
//$sql_fetch_todos2 = "select *  from usuarios a  INNER JOIN registros_material b group by nombre on a.nombre = b.nombre;";
$sql_fetch_todos2 = "select *  from registros_material_c where servicio = 'clara'  group by nombre ;";

$query2 = mysqli_query($conexion, $sql_fetch_todos2);

                while ($row2 = mysqli_fetch_assoc($query2)) { 
                 echo "['" .$row2['nombre']. "'," .$row2['id']. "],";
                }
?>
        ]);

        var options = {
          title: 'GRÁFICA PARA CLARA BRUGADA POR LIDER'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart2'));

        chart.draw(data, options);
      }
    </script>   
    
    
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {

        var data = google.visualization.arrayToDataTable([
          ['Task', 'Hours per Day'],
<?php
//$sql_fetch_todos2 = "select *  from usuarios a  INNER JOIN registros_material b group by nombre on a.nombre = b.nombre;";
$sql_fetch_todos3 = "select *  from registros_material_c where servicio = 'sheimbaun'  group by nombre ;";

$query3 = mysqli_query($conexion, $sql_fetch_todos3);

                while ($row3 = mysqli_fetch_assoc($query3)) { 
                 echo "['" .$row3['nombre']. "'," .$row3['id']. "],";
                }
?>
        ]);

        var options = {
          title: 'GRÁFICA  PARA CLAUDIA SHEINBAUM POR LIDER'
        };

        var chart = new google.visualization.PieChart(document.getElementById('piechart3'));

        chart.draw(data, options);
      }
    </script>
    
    
    <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['ID','CLARA', 'CLAUDIA'],
<?php
//$sql_fetch_todos2 = "select *  from usuarios a  INNER JOIN registros_material b group by nombre on a.nombre = b.nombre;";
$sql_fetch_todos4 = "select *  from registros_material_c  group by servicio ;";

$query4 = mysqli_query($conexion, $sql_fetch_todos4);

                while ($row4 = mysqli_fetch_assoc($query4)) { 
                 echo "[" .$row4['id']. ",'" .$row4['servicio'].  "','" .$row4['nombre'].  "'],";
                }q
?>
        ]);

        var options = {
          chart: {
            title: 'EVIDENCIAS',
            subtitle: 'CLAUDIA SHEINBAUM',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('chart_div'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>
    
    
    
    

        <script type="text/javascript">
      google.charts.load('current', {'packages':['bar']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['ID','CLARA','LIDER'],
<?php
//$sql_fetch_todos2 = "select *  from usuarios a  INNER JOIN registros_material b group by nombre on a.nombre = b.nombre;";
$sql_fetch_todos4 = "select * from registros_material_c where servicio = 'clara'";

$query4 = mysqli_query($conexion, $sql_fetch_todos4);

                while ($row4 = mysqli_fetch_assoc($query4)) { 
                 echo "[" .$row4['id']. ",'" .$row4['servicio'].  "','" .$row4['nombre']."'],";
                }
?>
        ]);

        var options = {
          chart: {
            title: 'EVIDENCIAS',
            subtitle: 'CLARA BRUGADA',
          }
        };

        var chart = new google.charts.Bar(document.getElementById('chart_div2'));

        chart.draw(data, google.charts.Bar.convertOptions(options));
      }
    </script>


    
    
  </head>
  <body>
      
     <div class="nav">
         <div class="row">
            <div class="col-md-4" >
                  <button class="btn" style="width:100%;height:50px;background-image: linear-gradient(#98989A, #9F2241);"><a href="reportes.php" style="color:white;"><li class="fa fa-list">  REPORTE GENERAL</li></a></button>

            </div>
            <div class="col-md-4">
                  <button style="width:100%;height:50px;" class="btn"><a href="reporte_lista.php" style="color:black;"><li class="fa fa-list">  REPORTE POR LIDER</li></a></button>

            </div>   
            <div class="col-md-4">
                  <button style="width:100%;height:50px;" class="btn"><a href="reporte_rangos.php" style="color:black;"><li class="fa fa-list">  REPORTE POR RANGOS</li></a></button>

            </div>            
         </div>
     </div>
    <div id="piechart" style="width: 100%; height: 500px;"></div>
    <br>
    <div id="piechart3" style="width: 100%; height: 500px;"></div>
    <br>
    <div id="piechart2" style="width: 100%; height: 500px;"></div> 
    <br>
    <div id="chart_div" style="width: 100%; height: 1000px;"></div> 
    <br>
    <div id="chart_div2" style="width: 100%; height: 1200px;"></div> 
    <br>
  

  </body>
    <!-- Fin Contenido PHP-->
    <?php
}
else
{
 require 'noacceso.php';
}
require 'footer.php';
}
ob_end_flush();
?>