<?php

 require_once "Conexion.php";
            
            $folio = $_GET['folio'];
            $sql_fetch_todos = "select * from folios2024 where folio=".$_GET['folio'];
            $query = mysqli_query($conexion, $sql_fetch_todos);

            
             if($datos=mysqli_fetch_array($query)){

   

    
    
include "fpdf/fpdf.php";





$pdf = new FPDF();
$pdf->AddPage();

$pdf->AddFont('Calibri-Light','','Calibri.php');
$pdf->AddFont('Calibri-Bold','','calibrib.php');
$pdf->AddFont('Calibri-italic','','calibri-light-italic.php');
$pdf->AddFont('Calibriz','','CALIBRIZ.php');
$pdf->AddFont('Avenir-Book','','Avenir-Book.php');
$pdf->AddFont('Avenir-Next-LT-Pro-Bold','','Avenir-Next-LT-Pro-Bold.php');
$pdf->AddFont('Metropolis-LightItalic','','Metropolis-LightItalic.php');
$pdf->AddFont('Metropolis-ExtraBoldItalic','','Metropolis-ExtraBoldItalic.php');










        $pdf->SetTitle($datos['folio']);
        $pdf->Image('impresion.png', 0, 0, 210, 280); 
        
        $pdf->SetFont('Avenir-Next-LT-Pro-Bold', '', 12);
        $pdf->Ln(12);
        $pdf->Cell(110,0," ");
        $pdf->Ln(10.5);
        $pdf->Cell(110,0," ");
        $pdf->SetTextColor(0,0,0);

        
        setlocale(LC_ALL,"es_ES");
        $pdf->SetXY(100 , 32.5); 
        $pdf->Cell(0, 0,iconv('utf-8', 'ISO-8859-1','Ciudad de México a '. $datos['fecha'] . ' del '. strftime('%Y')));

        $pdf->SetTextColor(178,34,34);
        $pdf->SetFont('Avenir-Next-LT-Pro-Bold', '', 11);
        $pdf->SetXY(146 , 42.5);         
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1',"".$datos['folio']));

$pdf->SetTextColor(0,0,0);
//origen 

$pdf->SetFont('Courier', 'B', 11);
$mystring2 = $datos['origen'];
$findme2   = 'DM';
$pos2 = strpos($mystring2, $findme2);
if ($pos2 === false) {
} else {
        $pdf->SetXY(10.5 , 41.5);  
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
}


$mystring3 = $datos['origen'];
$findme3   = 'SAC';
$pos3 = strpos($mystring3, $findme3);
if ($pos3 === false) {
} else {
        $pdf->SetXY(30 , 41.5);  
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
}


$mystring4 = $datos['origen'];
$findme4   = 'JTJ';
$pos4 = strpos($mystring4, $findme4);
if ($pos4 === false) {
} else {
        $pdf->SetXY(49.5 , 41.5);  
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
}


$mystring13 = $datos['area'];
$findme13   = 'DGA';
$pos13 = strpos($mystring13, $findme13);
if ($pos13 === false) {
} else {
        $pdf->SetXY(39.8 , 84.4);  
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));

} 
                 
                 
//areas
                 
$mystring5 = $datos['area'];
$findme5   = 'J';
$pos5 = strpos($mystring5, $findme5);
if ($pos5 === false) {
} else {
        $pdf->SetXY(39.8 , 55);                                    
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x")); 
}
      
$mystring6 = $datos['area'];
$findme6   = 'DECSII';
$pos6 = strpos($mystring6, $findme6);
if ($pos6 === false) {
} else {
        $pdf->SetXY(88.5 , 55); 
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));

}


$mystring7 = $datos['area'];
$findme7   = 'DEMCGG';
$pos7 = strpos($mystring7, $findme7);
if ($pos7 === false) {
} else {
        $pdf->SetXY(138.5 , 54.7);  
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));

}


$mystring8 = $datos['area'];
$findme8   = 'DGSU';
$pos8 = strpos($mystring8, $findme8);
if ($pos8 === false) {
} else {
        $pdf->SetXY(39.8 , 64.8);   
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));

}     


$mystring9 = $datos['area'];
$findme9   = 'DGPCGS';
$pos9 = strpos($mystring9, $findme9);
if ($pos9 === false) {
} else {
        $pdf->SetXY(89, 65.4);   
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));

}     

  

$mystring10 = $datos['area'];
$findme10   = 'DEFC';
$pos10 = strpos($mystring10, $findme10);
if ($pos10 === false) {
} else {
        $pdf->SetXY(138.5 , 65); 
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));

}  

             
$mystring11 = $datos['area'];
$findme11   = 'DGODU';
$pos11 = strpos($mystring11, $findme11);
if ($pos11 === false) {
} else {
        $pdf->SetXY(40 , 74.6);   
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));

} 

  
$mystring11 = $datos['area'];
$findme11   = 'DGIT';
$pos11 = strpos($mystring11, $findme11);
if ($pos11 === false) {
} else {
        $pdf->SetXY(89 , 75.5);  
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));

} 

   
$mystring12 = $datos['area'];
$findme12   = 'DECRD';
$pos12 = strpos($mystring12, $findme12);
if ($pos12 === false) {
} else {
        $pdf->SetXY(138.5 , 75.4);   
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));

} 




$mystring14 = $datos['area'];
$findme14   = 'DESCGIRPC';
$pos14 = strpos($mystring14, $findme14);
if ($pos14 === false) {
} else {
        $pdf->SetXY(89 , 85.4);  
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
} 


           
$mystring15 = $datos['area'];
$findme15   = 'DEDE';
$pos15 = strpos($mystring15, $findme15);
if ($pos15 === false) {
} else {
        $pdf->SetXY(138.5 , 85.4);  
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));

} 
                


$mystring = $datos['area'];
$findme   = 'DGDS';
$pos = strpos($mystring, $findme);
if ($pos === false) {
} else {
        $pdf->SetXY(40, 95.1);   
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
}


$mystring1 = $datos['area'];
$findme1   = 'DETAIPD';
$pos1 = strpos($mystring1, $findme1);
if ($pos1 === false) {
} else {
        $pdf->SetXY(88.9 , 95.8); 
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
}

          

                 
// tipo                 
                 
 
 $mystring16 = $datos['tipo'];
$findme16   = 'NORMAL';
$pos16 = strpos($mystring16, $findme16);
if ($pos16 === false) {
} else {
        $pdf->SetXY(10.5 , 109); 
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
}


 $mystring17 = $datos['tipo'];
$findme17   = 'URGENTE';
$pos17 = strpos($mystring17, $findme17);
if ($pos17 === false) {
} else {
        $pdf->SetXY(59 , 108.7); 
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
}


 $mystring18 = $datos['tipo'];
$findme18   = 'EXTEMPORANEO';
$pos18 = strpos($mystring18, $findme18);
if ($pos18 === false) {
} else {
        $pdf->SetXY(108 , 109); 
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
}                 
                 
            
 $mystring19 = $datos['tipo'];
$findme19   = 'CONOCIMIENTO';
$pos19 = strpos($mystring19, $findme19);
if ($pos19 === false) {
} else {
        $pdf->SetXY(157.6 , 108.8); 
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
} 

        $pdf->SetFont('Avenir-Next-LT-Pro-Bold', '', 10);         
        $pdf->SetXY(38 , 124);         
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1',"".$datos['oficio']));
                 
        
                 
                 
        //PROBLEMA DE LARGO DE CELDAS
                 
        $pdf->SetFont('Metropolis-ExtraBoldItalic', '', 11);         
        $pdf->SetXY(38 , 131);  
        $pdf->MultiCell(150,4,iconv('utf-8', 'ISO-8859-1',"".$datos['peticionario']));


                   
        $pdf->SetFont('Avenir-Book', '', 10);          
        $pdf->SetXY(38 , 151); 
        $pdf->MultiCell(156,4,iconv('utf-8', 'ISO-8859-1',"".$datos['asunto']));                    
           
                 
        $pdf->Image('pdf.png', 15, 190, 10, 10);                  
        


        $pdf->SetFont('Metropolis-LightItalic', '', 11,true);
        $pdf->SetXY(165 , 178);   
        $pdf->MultiCell(20,5,iconv('utf-8', 'ISO-8859-1',"".$datos['op']),'1',true);  
        
        $pdf->SetTextColor(0,0,0);
        $pdf->SetFont('Metropolis-LightItalic', 'U', 8);         
        $pdf->SetXY(38 , 225);
        $pdf->MultiCell(0,0,iconv('utf-8', 'ISO-8859-1',"".$datos['observaciones'])); 
                 

        $pdf->SetFont('Avenir-Book', '',11);         
        $pdf->SetXY(13 , 229);  
        $pdf->MultiCell(170,4,iconv('utf-8', 'ISO-8859-1',"".$datos['seguimiento']));     

        $pdf->SetFont('Avenir-Book', '', 11);         
        $pdf->SetXY(13 , 240);  
        $pdf->MultiCell(170,4,iconv('utf-8', 'ISO-8859-1',"".$datos['nota1'])); 

        $pdf->SetFont('Avenir-Book', '', 11);         
        $pdf->SetXY(13 , 244);  
        $pdf->MultiCell(170,4,iconv('utf-8', 'ISO-8859-1',"".$datos['nota2']));        
                 
             
        $pdf->SetFont('Courier', 'B', 11);                 
 $mystring20 = $datos['tipocorreo'];
$findme20   = 'CORREO';
$pos20 = strpos($mystring20, $findme20);
if ($pos20 === false) {
} else {
        $pdf->SetXY(54 , 253.5); 
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
} 


 $mystring21 = $datos['tipocorreo'];
$findme21   = 'SP';
$pos21 = strpos($mystring21, $findme21);
if ($pos21 === false) {
} else {
        $pdf->SetXY(117.5 , 253.3); 
        $pdf->Cell(0,0,iconv('utf-8', 'ISO-8859-1'," x"));
} 




             
                 
                 
                 
                 

$pdf->output();

             }

?>

