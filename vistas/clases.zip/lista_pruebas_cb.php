<?php
//Activamos el almacenamiento en el buffer
ob_start();
session_start();
date_default_timezone_set("America/Mazatlan");

if (!isset($_SESSION["nombre"]))
{
  header("Location: login.html");
}
else
{
require 'header.php';

if ($_SESSION['Escritorio']==1)
{
    
require_once "../config/Conexion.php";

if(!$_GET){
    header('Location: lista_pruebas_cb.php?pagina=1');
}


$TAMANO_PAGINA = 10;
     //examino la página a mostrar y el inicio del registro a mostrar
$pagina = ($_GET['pagina']-1)*$TAMANO_PAGINA;
if (!$pagina) {
    $inicio = 0;
    $pagina=1;
}
else {
    $inicio = ($pagina - 1) * $TAMANO_PAGINA;
}
$sql_fetch_todos = "SELECT * FROM registros_material_c where servicio = 'clara' order by id DESC LIMIT $pagina,$TAMANO_PAGINA";
$query = mysqli_query($conexion, $sql_fetch_todos);
$numero = mysqli_num_rows($query);


$sql_fetch_todos1 = "SELECT * FROM registros_material_C where servicio = 'clara' order by id DESC";
$query1 = mysqli_query($conexion, $sql_fetch_todos1);
$numero1 = mysqli_num_rows($query1);


$hora =  date('Y-m-d H:i:s');   
?>
                
<head>
    <style>
        .table-responsive {
            display: block;
            width: 100%;
            overflow-x: auto;
        }    
        
        .boton : hover {
            background-image: linear-gradient(#9F2241, #98989A);
        }
    </style>
</head>

<body>

	    <div class="container">
	        <div class="col-md-6">
	            <a href="lista.php"><button><img src="img/sheimbaun.png" width="100%"></button></a>
	        </div>
	        
	        <div class="col-md-6">
	            <a href="lista_c.php"><button><img src="img/clara.png" width="100%"></button></a>
	        </div>                			        
	    </div>
                			    
                		<br>
                		
                		
<h1 style="color:#AF272F;">LISTA DE REGISTROS PARA CLARA BRUGADA <button><a href="lista_c.php"><li class="fa fa-list"></li></a></button></h1>                		
        <div class="input-group" style="width:100%;background-image: linear-gradient(#98989A, #9F2241);">
          <div class="input-group-prepend">
            <span class="input-group-text" id="basic-addon1" style="background-color:#9F2241;color:white;border-radius: 5px;font-size:1.3em;"><strong>Filtro de tabla: </strong><span style="color:yellow;"><?php  echo $numero;?> filas</span></span>
          </div>
          <input id="entradafilter" type="text" class="form-control" placeholder="Ingrese concepto de busqueda" aria-label="Alumno" aria-describedby="basic-addon1">
        </div> 
<br>

                		
     <div class="table-responsive">


                    
        <table class="table table-striped">
            

            <br>
            
    <script>
                $(document).ready(function () {
           $('#entradafilter').keyup(function () {
              var rex = new RegExp($(this).val(), 'i');
                $('.contenidobusqueda tr').hide();
                $('.contenidobusqueda tr').filter(function () {
                    return rex.test($(this).text());
                }).show();
        
                })
        
        });
    </script>     



	    
                			    


            <tr style="background-image: linear-gradient(#98989A, #9F2241);color:white;font-size:1.2em;">
                <th scope="col">ID</th>
                <th scope="col">COLABORADOR</th>
                <th scope="col">AUXILIAR</th>
                <th scope="col">CONCEPTO</th>     
                <th scope="col">CANTIDAD JUSTIFICADA <br> EN IMAGEN</th>                     
                <th scope="col">FECHA</th>
                <th scope="col">HORA</th>
                <th scope="col">LATITUD</th>
                <th scope="col">LONGITUD</th>
                <th scope="col">DIRECCIÓN</th>
                <th scope="col">OPCIONES</th>
            </tr>
            <tbody class="contenidobusqueda">
                <?php
                while ($row = mysqli_fetch_array($query)) { ?>
                    <tr style="font-size:1.2em;color:black;">
                        <td style="max-width: 100%;"><?php echo $row['id'] ?></td>
                        <td style="max-width: 100%;"><?php echo $row['nombre'] ?></td>
                        <td style="max-width: 100%;"><?php echo $row['auxiliar'] ?></td>
                        <td style="max-width: 100%;"><?php echo $row['concepto'] ?></td>
                        <td style="max-width: 100%;"><?php echo $row['telefono'] ?></td>
                        <td style="max-width: 100%;"><?php echo $row['curp'] ?></td>
                        <td style="max-width: 100px;"><?php echo $row['direccion'] ?></td>
                        <td style="max-width: 100px;"><?php echo $row['lat'] ?></td>
                        <td style="max-width: 100px;"><?php echo $row['lon'] ?></td>
                        <td style="max-width: 100px;"><?php echo $row['tipo'] ?></td>
                          
                        
                        
                        <td>
                        <a target="_blank" class="boton fa fa-eye btn" href="ver_evidencia.php?id=<?php echo $row['id'];?>" role="button" style="color:white;background-image: linear-gradient(#98989A, #9F2241);">
                                EVIDENCIA
                            </a>
                        <a class="boton fa fa-map-marker btn" href="mapeo.php?id=<?php echo $row['id'];?>" role="button" style="color:white;background-image: linear-gradient(#98989A, #9F2241);">
                                MAPEAR
                            </a>
                        <a class="boton fa fa-edit btn" href="editar_lista.php?id=<?php echo $row['id'];?>" role="button" style="color:white;background-image: linear-gradient(#98989A, #9F2241);">
                                EDITAR
                            </a>                            
                        <a class="boton fa fa-dashboard btn" href="reportes/reporte_evidencias_cs.php?id=<?php echo $row['id'];?>" role="button" style="color:white;background-image: linear-gradient(#98989A, #9F2241);">
                                DIAPOSITIVA
                            </a                            

                     
                            

                        </td>

                    </tr>
                <?php
                } ?>
            </tbody>
        
            
        </table>
        <br>

    <?php
    



$total_paginas = $numero1 / $TAMANO_PAGINA;
$t_p = $pagina / 10 +1;
//pongo el número de registros total, el tamaño de página y la página que se muestra
echo "<a style='color:white;background-color:#AF272F;'>Número de registros encontrados:</a> " . $numero . "<br>";
echo "<a style='color:white;background-color:#AF272F;'>Se muestran páginas de </a>" . $TAMANO_PAGINA . " registros cada una<br>";
echo "<a style='color:white;background-color:#AF272F;'>Mostrando la página </a>" . $t_p . " de " . $total_paginas  . "<p>";




    
    //muestro los distintos índices de las páginas, si es que hay varias páginas
if ($total_paginas > 1){
    for ($i=1;$i<=$total_paginas;$i++){
       if ($pagina == $i)
          //si muestro el índice de la página actual, no coloco enlace
          echo $pagina . " ";
       else
          //si el índice no corresponde con la página mostrada actualmente, coloco el enlace para ir a esa página
          echo "<button style='color:white;background-color:#AF272F;border-radius:10px;'><a style='color:white;background-color:#AF272F;' href='lista_pruebas_cb.php?pagina=" . $i . "'>" . $i . "
          </a></button> ";
    }
}


    ?>

    </div>   
<br><br><br><br><br><br><br><br><br><br><br><br><br>
    <!-- Fin Contenido PHP-->
    <?php
}
else
{
 require 'noacceso.php';
}


mysqli_free_result($query);
mysqli_close($conexion);
require 'footer.php';
?>
        <script type="text/javascript" src="scripts/clientes.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min.js"></script>
        

<?php 
}
ob_end_flush();
?>




</body>   
