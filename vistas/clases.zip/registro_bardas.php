<?php
//Activamos el almacenamiento en el buffer
ob_start();
session_start();

if (!isset($_SESSION["nombre"]))
{
  header("Location: login.html");
}
else
{
require 'header.php';

if ($_SESSION['Escritorio']==1 || $_SESSION['Captura']==1)
{
date_default_timezone_set('America/Mazatlan');
$fecha_actual = date("d-m-Y");
$hora_actual = date("h:i:s");


$concepto = $_GET['concepto'];
?>
<!--Contenido-->

<body>



<style>
input[type=checkbox]
{
  /* Doble-tamaño Checkboxes */
  -ms-transform: scale(2); /* IE */
  -moz-transform: scale(2); /* FF */
  -webkit-transform: scale(2); /* Safari y Chrome */
  -o-transform: scale(2); /* Opera */
  padding: 10px;
}

/* Tal vez desee envolver un espacio alrededor de su texto de casilla de verificación */
.checkboxtexto
{
  /* Checkbox texto */
  font-size: 110%;
  display: inline;
}
</style>



<script>
    function Saltar(pal){
if (pal=='sesamo'){window.location="secreta.html"}
else {
    alert ('Respuesta equivocada')
    
    
    
    }
}
</script>

	<!-- Termina la definición del menú -->
	<main role="main" class="container">
	    
    
				<h1 style="text-align:center;font-family: sans-serif;color:#C91313;"><strong>CARGAR EVIDENCIA DE COLOCACIÓN DE: <h1 style="color:green;">"<?php echo $concepto;?> Y GALLARDETES"</h1></strong></h1>

	    
			<!-- Aquí pon las col-x necesarias, comienza tu contenido, etcétera -->
			
			
                <form action="cargar.php" method="POST" enctype="multipart/form-data" style="background-color:#DEB9B4;width:100%;text-align:center;">
                		<br>
                			<div class="col-12">
                			    
                			    <label style="color:red;font-size:1.5em;"> Seleccione de que candidata es el registro <br>(marcar solo una casilla)</label>
                			     
  			    
                			    <div class="container">
                			        <div class="col-md-6">
                			            <input type="checkbox" value="sheimbaun" name="quien" class="only-one">
                			            <img src="img/sheimbaun.png" width="20%">
                			        </div>
                			        <br>
                			        <div class="col-md-6">
                			            <input type="checkbox" value="clara" name="quien" class="only-one">
                			            <img src="img/clara.png" width="20%">
                			        </div>                			        
                			    </div>
                			    
                			    <br>
                			    <label style="color:red;font-size:1.3em;">Favor de ingresar aqui la dirección de entrega de forma manual o bien, <br>omitir esta casilla y dar click en el boton cargar coordenadas antes de generar el registro</label>
                			    <br>
                			    <textarea type="text" name="tipo" cols="40" rows="3" placeholder="ubicación manual"></textarea>
                			    

                                <input type="number" name="telefono"  value="1" hidden>
                                <br><br>
                			    
                			    
                			    <input type="text" name="icon" value="https://systemx.website/sistemamorena/vistas/img/icono.png" hidden>   
                			    
                                <input type="text" name="concepto" hidden value="<?php echo $concepto;?>">
                			    
                                <input type="text" name="nombre" hidden value="<?php echo $_SESSION["nombre"];?>">
                                
                                
                                <input type="text" name="curp" hidden value="<?php echo $fecha_actual;?>">
                                
                                <input type="text" name="direccion" hidden value="<?php echo $hora_actual;?>">
                                
                			    <label  style="color:red;font-size:1.5em;"><li class="fa fa-arrow-down"> </li> Adjunte fotografía de <?php echo $concepto;?> colocados <li class="fa fa-arrow-down"> </li></label>
                			    <br>                          
                                <input class="form-control text-center col-md-6" type="file" name="foto" style="background-color:greenyellow;height:80px;border-radius:20px;">     
                                <br><br><br>
                				<textarea id="latitud" name="lat" hidden></textarea>
                				<textarea id="longitud" name="lon" hidden></textarea>
                				
                				

                				               				
                            <br><br>
                			 <label style="color:red;font-size:1.3em;">Ingrese aqui el nombre de la persona auxiliar que esta llevando a cabo este registro</label>
                			 <br>
                             <input type="text" name="auxiliar" placeholder="NOMBRE DE QUIEN CAPTURA" style="width:40%;">
                             
                			<br><br>
                		    	<button type="submit" class="btn btn-info" style="float:right;width:50%;height:80px;"><strong>2</strong><br> GENERAR REGISTRO</button>
                			
                			</div>          

                </form>		
                

    
                    <button id="btnIniciar" class="btn btn-success" style="float:left;width:50%;height:80px;"><strong>1</strong><br> CARGAR COORDENADAS</button>	

	</main>
	
<br><br><br>	

	<script src="scripts/script_coordenadas.js">
	</script>
  <!--Fin-Contenido-->
<?php
}

require 'footer.php';
?>
<script src="../public/js/chart.min.js"></script>
<script src="../public/js/Chart.bundle.min.js"></script> 
<script type=text/javascript>

document.oncontextmenu = function(){return false;}

</script>


              <script>
                  let Checked = null;
                    //The class name can vary
                    for (let CheckBox of document.getElementsByClassName('only-one')){
                    	CheckBox.onclick = function(){
                      	if(Checked!=null){
                          Checked.checked = false;
                          Checked = CheckBox;
                        }
                        Checked = CheckBox;
                      }
                    }
              </script>
              
              
              
<?php 
}
ob_end_flush();
?>

