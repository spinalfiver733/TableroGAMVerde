<?php
//Activamos el almacenamiento en el buffer
ob_start();
session_start();

if (!isset($_SESSION["nombre"]))
{
  header("Location: login.html");
}
else
{
require 'header.php';

if ($_SESSION['Escritorio']==1 || $_SESSION['Captura']==1)
{

?>
<!--Contenido-->



<style>
  .columna{
        background: linear-gradient(#e66465, #9198e5);
        border-radius:15%;
  }
  .columna:hover{
        background: linear-gradient(#9198e5 , #e66465);
        border-radius:15%;      
  }
</style>

<body>

<br>

 
        <div class="container" style="text-align:center;width:100%;">
            
            <h1 style="color:#9F2241;">Seleccione el tipo de registro que desea realizar:
                    <br><br><li class="fa fa-arrow-down"></li><br><br>
            </h1>
                <a href="registro_bardas.php?concepto=LONAS">
                    <button class="columna">
                    <br>    
                      <h1 style="color:white;"><strong> > REGISTRAR EVIDENCIA</strong></h1>
                    </button>
                    <br>
                </a>
                
                <br>
                <a href="recepcion.php">
                    <button class="columna">
                    <br>    
                      <h1 style="color:white;"><strong> > REGISTRAR RECEPCIÓN DE MATERIAL</strong></h1>
                    </button>
                    <br>
                </a>
                
                <br>
                <a href="entrega.php">
                    <button class="columna">
                    <br>    
                      <h1 style="color:white;"><strong> > REGISTRAR ENTREGA DE MATERIAL A LIDERES</strong></h1>
                    </button>
                    <br>
                </a>                
                
                
        </div>   
        <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> 



<br>
<?php
}

require 'footer.php';
?>
<script type="text/javascript" src="scripts/categoria.js"></script>
<script src="../public/js/chart.min.js"></script>
<script src="../public/js/Chart.bundle.min.js"></script> 
<script type=text/javascript>

document.oncontextmenu = function(){return false;}

</script>
<?php 
}
ob_end_flush();
?>

