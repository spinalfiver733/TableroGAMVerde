<?php

require_once "../config/Conexion.php";


$auxiliar = $_POST['auxiliar'];
$quien = $_POST['quien'];
$nombre = $_POST['nombre'];
$telefono = $_POST['telefono'];
$curp = $_POST['curp'];
$direccion = $_POST['direccion'];
$lat = $_POST['lat'];
$lon = $_POST['lon'];
$icon = $_POST['icon'];
$tipo = $_POST['tipo'];
$concepto = $_POST['concepto'];




    $foto = $_FILES['foto']['name'];
    $ruta = $_FILES['foto']['tmp_name'];
    $destino = "fotos/" . $foto;

    if ($foto != "") {
        if (copy($ruta, $destino)) {


        
        $insert = $conexion->query("INSERT INTO registros_material_c (nombre,telefono,lat,lon,curp,direccion,foto,tipo,icon,concepto,servicio,auxiliar) VALUES ('$nombre','$telefono','$lat','$lon','$curp','$direccion','$foto','$tipo','$icon','$concepto','$quien','$auxiliar')");
        
            
            
        if($insert){
            header('Location: lista.php');
            die();
        }else{
            echo " por favor intente de nuevo el registro ... ";
        } 

}
}

?>


<script type=text/javascript>

document.oncontextmenu = function(){return false;}

</script>